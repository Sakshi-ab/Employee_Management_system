from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from salary import views
from .views import create, dashboard, delete, edit

app_name = 'salary'

urlpatterns = [
    path('create', views.create, name='salary_create'),
    path('dashboard', views.dashboard, name='salary_dashboard'),
    path('delete/<rid>', views.delete, name='salary_delete'),
    path('edit/<rid>', views.edit, name='salary_edit'),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)