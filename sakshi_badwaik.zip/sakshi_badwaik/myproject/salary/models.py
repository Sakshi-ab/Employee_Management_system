from django.db import models


# Create your models here.



class EmployeeSalary(models.Model):
    
    name = models.CharField(max_length=255, default="Unknown")  
    salary_amount = models.DecimalField(max_digits=10, decimal_places=2)
    start_date = models.DateField()

    

    def __str__(self):
        return f"{self.name} - {self.salary_amount} ({self.start_date})"