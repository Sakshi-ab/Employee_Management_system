from django.shortcuts import render, HttpResponse, get_object_or_404, redirect


from .models import EmployeeSalary

def create(request):
    if request.method == 'GET':
        return render(request, 'salary_create.html')
    elif request.method == 'POST':
        name = request.POST['name']
        salary = request.POST['salary']
        date = request.POST['date']

        # Use the EmployeeSalary constructor to create an instance
        M = EmployeeSalary(
            name=name,
            salary_amount=salary,  # Corrected field name
            start_date=date  # Corrected field name
        )

        M.save()  # Save the instance to the database

        v = EmployeeSalary.objects.all()  # Retrieves all records from the EmployeeSalary model's table
        context = {'data': v}
        return render(request, "salary_dashboard.html", context)

def dashboard(request):
    salaries = EmployeeSalary.objects.all()
    context = {'data': salaries}
    return render(request, 'salary_dashboard.html', context)



       


def delete(request,rid):
   m = EmployeeSalary.objects.filter(id = rid)
   m.delete()
   return redirect('salary:salary_dashboard')

def edit(request, rid):
    if request.method == 'GET':
        m = EmployeeSalary.objects.filter(id=rid)
        context = {'data': m}
        return render(request, "salary_edit.html", context)
    elif request.method == 'POST':
        uname = request.POST['name']
        usalary = request.POST['salary']
        udate = request.POST['date']
        

        m = EmployeeSalary.objects.filter(id=rid)

        m.update(
            name=uname,
            salary_amount=usalary,
            start_date=udate,
            
        )

        return redirect('salary:salary_dashboard')