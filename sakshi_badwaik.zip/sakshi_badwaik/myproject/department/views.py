from django.shortcuts import render, HttpResponse, get_object_or_404, redirect
from .models import Department


def create(request):
    if request.method == 'GET':
        return render(request, 'department_create.html')
    elif request.method == 'POST':
        department = request.POST['department']  # Corrected from 'name' to 'department'
        floor = request.POST['floor']
        head_manager = request.POST['head_manager']

        # Use the Department constructor to create an instance
        M = Department(
            name=department,
            floor=floor,
            head_manager=head_manager
        )

        M.save()  # Save the instance to the database

        v = Department.objects.all()  # Retrieves all records from the Department model's table
        context = {'data': v}
        return render(request, "department_dashboard.html", context)     



def dashboard(request):
    departments = Department.objects.all()
    context = {'data': departments}
    return render(request, 'department_dashboard.html', context)


       


def delete(request,rid):
   m = Department.objects.filter(id = rid)
   m.delete()
   return redirect('department:department_dashboard')

def edit(request, rid):
    if request.method == 'GET':
        m = Department.objects.filter(id=rid)
        context = {'data': m}
        return render(request, "department_edit.html", context)
    elif request.method == 'POST':
        udepartment = request.POST['name']
        ufloor = request.POST['floor']
        uhead_manager = request.POST['head_manager']
        

        m = Department.objects.filter(id=rid)

        m.update(
            name=udepartment,
            floor=ufloor,
            head_manager=uhead_manager,
            
        )

        return redirect('department:department_dashboard')
    



