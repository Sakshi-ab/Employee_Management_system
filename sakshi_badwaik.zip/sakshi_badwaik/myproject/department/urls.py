from django.contrib import admin
from django.urls import path
from department import views
from django.conf import settings
from django.conf.urls.static import static
from .views import create, dashboard, delete, edit

app_name = 'department'

urlpatterns = [
    path('create', views.create, name='department_create'),
    path('dashboard', views.dashboard, name='department_dashboard'),
    path('delete/<rid>', views.delete, name='department_delete'),
    path('edit/<rid>', views.edit, name='department_edit'),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

    