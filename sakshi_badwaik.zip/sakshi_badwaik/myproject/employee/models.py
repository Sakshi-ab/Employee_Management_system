from django.db import models

# Create your models here.
class Employee(models.Model):
     DESIGNATION_CHOICES = [
        ('Associate', 'Associate'),
        ('TL', 'Team Lead'),
        ('Manager', 'Manager'),
    ]

     REPORTING_MANAGER_CHOICES = [
        ('TL', 'Team Lead'),
        ('Manager', 'Manager'),
    ]
     
     DEPARTMENT_CHOICES = [
        ('DEVELOPER', 'DEVELOPER'),
        ('TESTING','TESTING'),
        ('SALES', 'SALES'),
        
    ]
     name = models.CharField(max_length=255)
     email = models.EmailField(unique=True)
     address = models.TextField()

     designation = models.CharField(max_length=20, choices=DESIGNATION_CHOICES)
    
    
     reporting_manager = models.CharField(max_length=20, choices=REPORTING_MANAGER_CHOICES, )

    
     department = models.CharField(max_length=20, choices=DEPARTMENT_CHOICES)

     
    

     def __str__(self):
        return self.name
