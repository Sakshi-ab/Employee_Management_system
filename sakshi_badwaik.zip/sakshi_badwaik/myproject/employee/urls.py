from django.contrib import admin
from django.urls import path
from employee import views
from django.conf import settings
from django.conf.urls.static import static
from .views import create, dashboard, delete, edit

app_name = 'employee'

urlpatterns = [
    path('create',views.create, name='employee_create'),
    path('dashboard',views.dashboard, name='employee_dashboard'),
    path('delete/<rid>',views.delete, name='employee_delete'),
    path('edit/<rid>',views.edit,name='employee_edit'),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)



