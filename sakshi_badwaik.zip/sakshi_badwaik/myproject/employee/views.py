from django.shortcuts import render, HttpResponse, get_object_or_404, redirect

from department.models import Department
from .models import Employee

def create(request):
   # print(request.method)
   if request.method == 'GET':
    return render(request,'employee_create.html')
   elif request.method == 'POST':
     #else me post method hai and wo data send krra hai sql me
     name = request.POST['name']
     
     email = request.POST['email']
     
     address = request.POST['address']
     
     designation = request.POST['designation']

     reporting_manager = request.POST['reporting_manager']  # Fix here
     department = request.POST['department']  # Fix here

        # Use the Employee constructor to create an instance
     M = Employee(
            name=name,
            email=email,
            address=address,
            designation=designation,
            reporting_manager=reporting_manager,
            department=department
        )

     M.save()   #actually save method execute krega

     v = Employee.objects.all()  #retrieves all records from the  Employee" model's table
     context = {}
     context['data'] = v
     return render(request,"employee_dashboard.html", context )
     

def dashboard(request):
       
       m = Employee.objects.all()
       context = {}

       context['data'] = m
       
       return render(request,'employee_dashboard.html', context)

       


def delete(request,rid):
   m = Employee.objects.filter(id = rid)
   m.delete()
   return redirect('employee:employee_dashboard')

def edit(request, rid):
    if request.method == 'GET':
        m = Employee.objects.filter(id=rid)
        context = {'data': m}
        return render(request, "employee_edit.html", context)
    elif request.method == 'POST':
        uname = request.POST['name']
        uemail = request.POST['email']
        uaddress = request.POST['address']
        udesignation = request.POST['designation']
        ureporting_manager = request.POST['reporting_manager']
        udepartment = request.POST['department']

        m = Employee.objects.filter(id=rid)

        m.update(
            name=uname,
            email=uemail,
            address=uaddress,
            designation=udesignation,
            reporting_manager=ureporting_manager,
            department=udepartment
        )

        return redirect('employee:employee_dashboard')
    
